from django.contrib import admin

# Register your models here.
from .models import Emp
admin.site.register(Emp)

